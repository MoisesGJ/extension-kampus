const headerView = document.getElementsByTagName('header')[1];

const btn = document.createElement('button');
btn.classList.add('font-bold', 'my-5');
btn.textContent = 'Ver video';

headerView.prepend(btn);

btn.addEventListener('click', () => {
  const link = document.getElementsByTagName('iframe')[0]?.src;
  window.open(link);
});
